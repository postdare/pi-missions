/**
 * pi-missions · core 层共享类型
 *
 * 本文件及 core/ 下所有模块必须保持纯净:
 * 不 import pi、不读文件、不调用网络、不使用 Date.now() 之外的环境依赖。
 * 它们是整个系统唯一的裁判,必须可单测。
 */

// ─────────────────────────────── 基础枚举 ───────────────────────────────

export type Phase = "plan" | "do" | "check" | "act" | "done" | "halted";

export type Tier = "quick" | "standard" | "complex";

/** 升级阶梯:1=改实现 2=改方案 3=改问题定义 */
export type EscalationLevel = 1 | 2 | 3;

export type Role = "planner" | "executor" | "verifier" | "escalator";

// ─────────────────────────────── 证据 ───────────────────────────────

/**
 * hard —— 编译/测试/lint/类型检查的退出码。纯代码采集,零模型成本。
 * semi —— 逐条核对冻结 AC。由独立 Verifier 产出。
 * soft —— 执行者自述。只能触发 ACT,永远不能触发 PASS。
 */
export type EvidenceLevel = "hard" | "semi" | "soft";

export type EvidenceResult = "pass" | "fail" | "inconclusive";

export interface Evidence {
  level: EvidenceLevel;
  /** 对应的验收标准 id,如 "AC1";非 AC 类检查用检查名,如 "compile" */
  acId: string;
  result: EvidenceResult;
  /** 原始输出(已截断)。用于生成失败签名与归档 */
  raw: string;
  exitCode?: number;
  /** 采集该证据时的环境指纹。与 mission 记录不符则整份判定 inconclusive */
  envFingerprint?: string;
}

export type VerdictOutcome = "pass" | "fail" | "inconclusive";

export interface Verdict {
  outcome: VerdictOutcome;
  /** 失败签名。仅 outcome==="fail" 时有值,用于熔断计数 */
  signature?: string;
  failing: Evidence[];
  /** 人类可读的判定理由,直接写入 LOG.md */
  reason: string;
}

// ─────────────────────────────── 任务与 Mission ───────────────────────────────

export type TaskStatus = "pending" | "running" | "done" | "blocked";

export interface TaskState {
  id: string;
  status: TaskStatus;
  /** 已进行的 do→check 周期数,从 1 开始计 */
  attempts: number;
  /** 上一次失败的签名 */
  lastSignature?: string;
  /** 同一签名连续出现次数。签名变化时重置为 1 */
  sameSignatureCount: number;
}

export interface EscalationRecord {
  at: number;
  taskId: string;
  from: EscalationLevel;
  to: EscalationLevel;
  signature?: string;
  reason: string;
}

export interface MissionState {
  missionId: string;
  tier: Tier;
  phase: Phase;
  currentTask: string | null;
  /** 任务推进顺序。complex 档由里程碑展开而来 */
  taskOrder: string[];
  tasks: Record<string, TaskState>;
  escalation: {
    level: EscalationLevel;
    history: EscalationRecord[];
  };
  /** Plan 冻结时记录的环境指纹 */
  envFingerprint: string | null;
}

// ─────────────────────────────── 状态机 I/O ───────────────────────────────

export type MissionEvent =
  | { type: "PLAN_FROZEN"; at: number }
  | { type: "SUBMIT"; at: number }
  | { type: "VERDICT"; at: number; verdict: Verdict }
  /** ACT 相位完成调整,回到 DO 重试。由 breaker 判定 action==="retry" 后发出 */
  | { type: "ADJUST_DONE"; at: number }
  /** 由 breaker 判定 action==="escalate" 后发出 */
  | { type: "ESCALATE"; at: number; to: 2 | 3; reason: string }
  /** L3 需要人工确认;确认后重写 MISSION.md */
  | { type: "ESCALATION_CONFIRMED"; at: number }
  | { type: "ESCALATION_REJECTED"; at: number }
  | { type: "ABORT"; at: number; reason: string };

/**
 * 状态机产出的副作用。机器本身不执行任何一条,
 * 由 hooks 层翻译成 pi API 调用。这是 core 保持纯净的关键。
 */
export type Effect =
  | { type: "SET_TOOLS"; phase: Phase }
  | { type: "SET_ROLE"; role: Role }
  /** 换脑:创建干净上下文。I5 要求每次升级必须换 */
  | { type: "HANDOFF"; reason: string }
  | { type: "LOG"; line: string }
  | { type: "CONFIRM"; question: string }
  | { type: "ADVANCE_TASK"; taskId: string }
  | { type: "FREEZE_AC" }
  | { type: "ARCHIVE_PLAN"; reason: string }
  | { type: "NOTIFY"; level: "info" | "warning" | "error"; message: string };

export interface TransitionResult {
  state: MissionState;
  effects: Effect[];
  /** 非法迁移时填充。状态保持不变,调用方应记录并忽略该事件 */
  error?: string;
}
