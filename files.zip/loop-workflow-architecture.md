# 双层循环工作流引擎 · 架构方案

> 目标:在 pi coding agent 之上实现一套自有工作流。外层 PDCA 管任务分解与进度追踪,内层操控循环管执行中的质量控制与自我修正。提供 quick / standard / complex 三档。
>
> 实现载体:pi TypeScript Extension(`~/.pi/agent/extensions/loop/` 或项目级 `.pi/extensions/loop/`)

---

## 0. 设计不变量

这五条是整个系统的地基,后续所有实现细节都不得违反。任何一条被绕过,双层循环都会退化成"带仪式感的单层循环"。

| # | 不变量 | 违反后果 |
|---|---|---|
| **I1** | 状态是磁盘上的文件,不是会话里的对话 | 会话一断/一压缩,进度全丢 |
| **I2** | 验收标准在 Plan 阶段冻结,执行期只读 | agent 做不出来就悄悄放宽标准 |
| **I3** | 判定"对了/错了"的证据必须来自执行者之外 | Check 变成自我表扬 |
| **I4** | 熔断优先于重试:同一问题连续失败必须升级,不得继续微调 | 在错误方案上无限打磨 |
| **I5** | 每次升级必须换干净上下文 | 在被污染的上下文里"重新思考",只会得到同一错误的变体 |

---

## 1. 总体分层

```
┌─────────────────────────────────────────────────────────────┐
│  L0  控制面(Extension 进程内)                              │
│      Phase State Machine · Circuit Breaker · Gate           │
│      —— 纯 TypeScript,不经过 LLM,是唯一的裁判              │
└───────────────┬─────────────────────────────────────────────┘
                │ 读写
┌───────────────▼─────────────────────────────────────────────┐
│  L1  状态面(磁盘,.pi/loop/<run-id>/)                       │
│      PLAN.md(冻结) · STATE.json(可变) · LOG.md(追加)     │
└───────────────┬─────────────────────────────────────────────┘
                │ 注入 / 回写
┌───────────────▼─────────────────────────────────────────────┐
│  L2  执行面(pi session)                                     │
│      外层:Plan 会话   内层:Do 会话 · Check 会话             │
│      每个会话 = 一个干净上下文 + 一套受限工具集              │
└───────────────┬─────────────────────────────────────────────┘
                │ 采集
┌───────────────▼─────────────────────────────────────────────┐
│  L3  证据面(外部事实)                                       │
│      编译 · 测试 · lint · 类型检查 · 独立 Check 会话结论      │
└─────────────────────────────────────────────────────────────┘
```

关键:**L0 是唯一的裁判,L2 只是执行者**。LLM 永远不能自己宣布"我做完了"——它只能提交,由 L0 依据 L3 的证据判定。

---

## 2. 状态模型

### 2.1 目录结构

```
<project>/.pi/loop/
├── current                     # 指向当前 run-id 的软链/文本文件
└── runs/
    └── 2026-08-31-auth-refactor/
        ├── PLAN.md             # 冻结件:目标 + 任务分解 + 验收标准
        ├── STATE.json          # 可变件:进度 / 计数器 / 当前相位
        ├── LOG.md              # 追加件:每次调整的决策与理由
        └── evidence/
            └── T3-attempt2.txt # 证据快照(测试输出等)
```

用 `CONFIG_DIR_NAME` 常量拼路径,不要硬编码 `.pi`(pi 支持改名分发)。

### 2.2 PLAN.md(冻结件)

```markdown
# Run: auth-refactor
tier: standard
goal: 把登录鉴权从 session 迁移到 JWT,不影响现有接口契约

## Frozen Acceptance Criteria
> 本节在 Plan 阶段之后只读。需要修改必须走 /loop escalate --level=plan。

- AC1: `mvn -q test -Dtest=AuthIntegrationTest` 全绿
- AC2: 现有 `/api/**` 接口的响应体 schema 不变(对比 snapshot)
- AC3: 无新增 checkstyle 违规

## Tasks
- [ ] T1 引入 JwtProvider 与配置  (verify: mvn -q compile)
- [ ] T2 替换 SessionAuthFilter    (verify: mvn -q test -Dtest=AuthFilterTest)
- [ ] T3 迁移登录/登出端点         (verify: AC1)
- [ ] T4 契约回归                  (verify: AC2, AC3)
```

**AC 必须是可执行命令或可机械核对的断言。**写不成命令的 AC,说明这个任务还没想清楚,不该进入 Do 阶段。

### 2.3 STATE.json(可变件)

```jsonc
{
  "runId": "2026-08-31-auth-refactor",
  "tier": "standard",
  "phase": "do",                       // plan | do | check | act | done | halted
  "currentTask": "T3",
  "tasks": {
    "T1": { "status": "done",    "attempts": 1 },
    "T2": { "status": "done",    "attempts": 2 },
    "T3": { "status": "running", "attempts": 2, "lastFailure": "AuthIntegrationTest#refreshToken 断言失败" }
  },
  "escalation": { "level": 1, "history": [ /* … */ ] },   // 1=改实现 2=改方案 3=改问题定义
  "sessionMap": { "T3": ".pi/sessions/xxx.jsonl" },
  "updatedAt": 1756600000000
}
```

### 2.4 LOG.md(追加件)

排障时唯一要读的文件。每条一行,不写散文:

```
2026-08-31T10:22 T3 attempt=1 verdict=FAIL evidence=refreshToken断言失败 action=fix-impl
2026-08-31T10:41 T3 attempt=2 verdict=FAIL evidence=同一断言 action=fix-impl
2026-08-31T11:03 T3 attempt=3 verdict=FAIL evidence=同一断言 action=ESCALATE→L2 reason=连续3次同一失败点
2026-08-31T11:05 T3 escalate L2: 方案假设错误 —— refresh token 不应复用同一密钥
```

---

## 3. 相位状态机(L0 核心)

```
                 ┌──────────────────────────────────────┐
                 │                                      │
   ┌──────┐      ▼      ┌──────┐  submit  ┌───────┐     │
   │ PLAN │──freeze──▶ │  DO  │─────────▶│ CHECK │     │
   └──────┘             └──────┘           └───┬───┘     │
       ▲                   ▲                   │         │
       │                   │  PASS ┌───────────┴───┐FAIL │
       │                   │       ▼               ▼     │
       │                   │  next task ──▶   ┌─────┐    │
       │                   └──────────────────│ ACT │────┘
       │                    attempts < N      └──┬──┘
       │                                         │ attempts ≥ N
       └──────────── ESCALATE(L2/L3)◀───────────┘
```

### 相位 → 能力矩阵

L0 通过 `pi.setActiveTools()` 在相位切换时改写工具集,这是"闸门"的物理实现:

| 相位 | 可用工具 | thinking | 允许写文件 |
|---|---|---|---|
| PLAN | `read` `grep` `find` `ls` `loop_write_plan` | high | 仅 PLAN.md |
| DO | 全部 + `loop_submit` | medium | 是 |
| CHECK | `read` `bash` `loop_verdict` | medium | **否** |
| ACT | `read` `grep` `loop_escalate` | high | 否 |

> CHECK 相位禁写是 I3 的实现:验证者一旦能改代码,就会倾向于"顺手修一下"然后判自己通过。

---

## 4. pi 能力映射

| pi 机制 | 承担职责 |
|---|---|
| `pi.registerCommand("loop", …)` | `/loop new` `/loop status` `/loop next` `/loop escalate` `/loop abort` |
| `before_agent_start` | 注入 **State Card**(当前相位 + 任务 + AC + 尝试次数)并替换 systemPrompt 为相位提示词 |
| `tool_call`(可 block) | 相位闸门:PLAN 期拦截 `write`/`edit`,CHECK 期拦截一切写操作;未 `/loop new` 时不干预 |
| `tool_result` | 证据采集:识别 `bash` 跑测试的退出码,写入 `evidence/`,更新 verdict 候选 |
| `agent_settled` | 内层 tick:此刻 agent 已彻底停下,是判定 continue / adjust / escalate 的唯一安全点 |
| `pi.setActiveTools()` | 相位能力矩阵 |
| `pi.setThinkingLevel()` / `pi.setModel()` | 分相位模型策略(PLAN/ACT 用强模型 + high thinking,DO 用快模型) |
| `ctx.newSession()` / `ctx.fork()` | **换脑**:任务切换与升级时创建干净上下文(⚠️ 仅命令上下文可用,见 §6.3) |
| `pi.appendEntry()` + `registerEntryRenderer()` | 把 verdict / 升级事件渲染成 TUI 卡片,且**不进 LLM 上下文** |
| `ctx.getContextUsage()` | 上下文水位守卫:超阈值主动触发换脑而非等 auto-compact |
| `ctx.ui.setWidget()` | 常驻状态条:`[standard] T3 · attempt 2/3 · phase=do` |
| `session_start` | 从磁盘 + session entries 重建内存状态 |
| `pi.events` | 与其它扩展(LSP 反馈、sub-agent)解耦通信 |

---

## 5. 三档工作流

三档的差别**只在两个维度**:是否落 PLAN.md,以及换脑的粒度。不要为每档发明新概念。

| | quick | standard | complex |
|---|---|---|---|
| 入口 | `/loop q <任务>` | `/loop new <目标>` | `/loop new --tier=complex` |
| PLAN.md | 不落盘(AC 存内存) | 落盘,任务级 | 落盘,里程碑 + 任务级 |
| 分解粒度 | 单任务 | 任务列表 | milestone → task |
| CHECK 执行者 | 同会话自检(仅硬证据) | 同会话 + 硬证据 | **独立 Check 会话** |
| 换脑粒度 | 不换 | 每任务换一次 | 每任务换 + 每里程碑收敛 |
| 熔断阈值 N | 2 | 3 | 3(里程碑级另计) |
| 里程碑验证 | — | — | 有:回归 + 集成检查 |

### 5.1 升档规则(自动)

**升档自动,降档手动。** 这条比分档规则本身重要。

```ts
// L0 在 agent_settled 中评估
if (tier === "quick" && attempts >= 2) promoteTo("standard");   // 强制补 PLAN
if (touchedFiles.size > 5 || touchedPublicApi) promoteTo("standard");
if (tier === "standard" && milestoneDrift()) promoteTo("complex");
```

分档判据必须机械可测:**改动文件数、是否触及接口/数据模型、是否可逆、是否有既有测试覆盖**。不要让 LLM 自评"这个任务复杂吗"。

---

## 6. 关键机制

### 6.1 证据分级(I3 的落地)

```ts
type Verdict = { level: "hard" | "semi" | "soft"; pass: boolean; evidence: string };
```

- **hard** — 编译 / 测试 / lint / 类型检查的退出码。由 `tool_result` 自动采集,**不经过 LLM 转述**。
- **semi** — 逐条核对 PLAN.md 的 AC。complex 档必须由独立 Check 会话产出;standard 档可同会话但只允许 `read` + `bash`。
- **soft** — 执行者自述。**只能触发 ACT,不能触发 PASS。**

判定优先级:任一 hard FAIL → FAIL,无视其它。全部 hard PASS 且 semi PASS → PASS。其余 → ACT。

> Java 后端场景下 hard 证据极易获取(`mvn -q test` 的退出码就是),这是你的天然优势——内层可以做得很实,不必依赖 LLM 自评。

### 6.2 熔断与升级阶梯(I4)

```ts
const FAILURE_SIGNATURE = hash(normalize(evidence));  // 归一化失败点

if (sameSignatureCount >= N) {
  escalate();          // 不是再试一次,是换一层问题
}
```

三级阶梯,**每次只升一级**:

| 级别 | 动作 | 换脑 | 产物 |
|---|---|---|---|
| L1 | 改实现 | 否 | 新的 attempt |
| L2 | 改方案 → 回 PLAN | **是** | PLAN.md 的 Tasks 段重写(AC 不变) |
| L3 | 改问题定义 → 回目标 | **是** | 整个 PLAN.md 重写,旧的归档 |

L3 是唯一允许修改 Frozen AC 的路径,且必须人工确认(`ctx.ui.confirm`)。

**升级时携带的上下文只有三样**:PLAN.md、LOG.md 中该任务的失败记录、最后一次失败证据。**不携带失败会话的原始对话**——那正是要丢掉的污染源。

### 6.3 换脑机制(I5)⚠️ 实现陷阱

pi 的 `ctx.newSession()` / `ctx.fork()` / `ctx.switchSession()` 属于 `ExtensionCommandContext`,**只在命令处理器中可用**;事件处理器里调用会死锁。

所以换脑必须走这条链路:

```
agent_settled(事件) 判定需要换脑
   └─▶ pi.sendUserMessage("/loop next", { deliverAs: "followUp" })
          └─▶ /loop next(命令) 中执行 ctx.newSession({ setup, withSession })
```

并且严格遵守 pi 文档的 session replacement 规则:

```ts
pi.registerCommand("loop", {
  handler: async (args, ctx) => {
    // ✅ 只捕获纯数据(字符串、id、序列化配置)
    const brief = renderTaskBrief(state);   // string

    await ctx.newSession({
      parentSession: ctx.sessionManager.getSessionFile(),
      setup: async (sm) => {
        sm.appendMessage({ role: "user",
          content: [{ type: "text", text: brief }], timestamp: Date.now() });
      },
      withSession: async (ctx2) => {
        await ctx2.sendUserMessage("开始执行当前任务");  // ⚠️ 必须用 ctx2
      },
    });
    return;   // 换脑视为该 handler 的终点
  },
});
```

❌ 绝不能在 `withSession` 里使用外层捕获的 `pi` 或 `ctx`、或提前抽出的 `ctx.sessionManager`——它们在会话替换后已失效并会抛错。

### 6.4 上下文水位守卫

不要等 pi 的 auto-compact 兜底。压缩是有损的,而换脑是无损的(状态在磁盘上)。

```ts
pi.on("agent_settled", async (_e, ctx) => {
  const usage = ctx.getContextUsage();
  if (usage && usage.tokens > model.contextWindow * 0.5) {
    queueHandoff("context-watermark");   // → /loop next
  }
});
```

### 6.5 State Card 注入

每轮 `before_agent_start` 注入一张极简卡片。**注入的是当前相位需要的最小集合**,不是整个 STATE.json:

```
[LOOP] tier=standard phase=do task=T3 attempt=2/3
GOAL: 迁移登录/登出端点到 JWT
AC(冻结,不可修改):
  - AC1: mvn -q test -Dtest=AuthIntegrationTest 全绿
PREVIOUS FAILURE: AuthIntegrationTest#refreshToken 断言失败
你只需完成 T3。完成后调用 loop_submit,不要自行判定通过。
```

最后一句是刚需——否则 LLM 会自己宣布完成然后开始做 T4。

---

## 7. 代码结构

```
.pi/extensions/loop/
├── package.json          # { "pi": { "extensions": ["./src/index.ts"] } }
└── src/
    ├── index.ts          # 装配:注册命令/工具/事件
    ├── core/
    │   ├── machine.ts    # 相位状态机(纯函数,可单测)
    │   ├── breaker.ts    # 失败签名 + 熔断 + 升级阶梯
    │   └── verdict.ts    # 证据分级与判定
    ├── store/
    │   ├── plan.ts       # PLAN.md 读写 + AC 冻结校验
    │   ├── state.ts      # STATE.json(withFileMutationQueue 保护)
    │   └── log.ts        # LOG.md 追加
    ├── phases/
    │   ├── prompts.ts    # 四套相位提示词
    │   └── tools.ts      # 相位 → 工具集矩阵
    ├── hooks/
    │   ├── gate.ts       # tool_call 闸门
    │   ├── evidence.ts   # tool_result 证据采集
    │   └── tick.ts       # agent_settled 内层 tick
    └── ui/
        ├── widget.ts     # 状态条
        └── renderer.ts   # verdict / escalate 卡片
```

**`core/` 三个文件必须是纯函数且有单测。**它们是唯一的裁判,不能靠"跑一遍看看对不对"来验证。

### 自定义工具(LLM 可调用的仅这四个)

| 工具 | 相位 | 作用 |
|---|---|---|
| `loop_write_plan` | PLAN | 写入 PLAN.md;写入即冻结 AC |
| `loop_submit` | DO | 声明当前任务已提交,触发 CHECK(**不等于通过**) |
| `loop_verdict` | CHECK | 提交逐条 AC 核对结果(semi 证据) |
| `loop_escalate` | ACT | 主动请求升级,附理由 |

工具越少越好。状态推进由 L0 驱动,不要给 LLM 提供直接改 STATE.json 的工具。

---

## 8. 实施路线

**v0.1 — 只做 standard 档 + 熔断**(建议 1~2 天)

- PLAN.md / STATE.json / LOG.md 三件套
- 相位状态机 + tool_call 闸门
- hard 证据采集(bash 退出码)
- 熔断计数 + L2 升级
- 不做:quick/complex 档、独立 Check 会话、里程碑

用 2~3 个真实任务跑一遍,记录三个数:**内层平均迭代次数、熔断触发率、触发时真正的病根在哪一层**。

**v0.2 — 换脑与升级阶梯**

- `/loop next` 命令 + `newSession` 换脑
- L3 升级路径 + 人工确认
- 上下文水位守卫

**v0.3 — 分档**

- 从 v0.1 的数据反推 quick 该砍什么、complex 该加什么
- complex 档的独立 Check 会话与里程碑验证

> 分档规则应该是从数据里长出来的,不是先想好的。三档 × 双层 × 多角色一次性做,几乎必然过度设计。

---

## 9. 已知风险与开放问题

1. **相位提示词与 pi 内置 systemPrompt 的冲突。**`before_agent_start` 是链式的,你的修改可能被后加载的扩展覆盖。建议 loop 扩展放在加载顺序末位,并用 `ctx.getSystemPrompt()` 自检。

2. **并行工具执行下的 `tool_call` 时序。**pi 默认并行执行工具,`tool_call` 不保证能看到同批次兄弟工具的结果。闸门逻辑不要依赖"上一个工具的结果",只依赖 STATE。

3. **失败签名的归一化。**`hash(evidence)` 太严会导致同一病根算作不同失败(熔断永不触发),太松会误熔断。起步建议:只取测试类名 + 方法名 + 断言类型,忽略行号与堆栈。这是最需要按实际数据调的参数。

4. **换脑的成本。**每次换脑要重新读代码建立理解,standard 档"每任务换一次"可能过于激进。v0.1 先不换,用水位阈值触发,观察实际收益。

5. **Factory 的公开经验:串行 + 定点并行优于大面积并行。**本方案默认全串行是对的,不要过早引入多 worker 并行。

---

## 附:index.ts 骨架

```ts
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { CONFIG_DIR_NAME } from "@earendil-works/pi-coding-agent";
import { loadState, saveState } from "./store/state";
import { toolsForPhase, promptForPhase } from "./phases";
import { evaluate } from "./core/verdict";
import { shouldEscalate } from "./core/breaker";

export default function (pi: ExtensionAPI) {
  let state = null;   // 内存镜像,磁盘为准

  pi.on("session_start", async (_e, ctx) => {
    state = await loadState(ctx.cwd);
    if (state) {
      pi.setActiveTools(toolsForPhase(state.phase));
      ctx.ui.setWidget("loop", [renderStatus(state)]);
    }
  });

  // 注入 State Card + 相位提示词
  pi.on("before_agent_start", async (event) => {
    if (!state) return;
    return {
      message: { customType: "loop-state", content: renderCard(state), display: true },
      systemPrompt: `${event.systemPrompt}\n\n${promptForPhase(state.phase)}`,
    };
  });

  // 闸门
  pi.on("tool_call", async (event) => {
    if (!state) return;
    const denied = gateCheck(state.phase, event.toolName, event.input);
    if (denied) return { block: true, reason: denied };
  });

  // 证据采集
  pi.on("tool_result", async (event, ctx) => {
    if (!state) return;
    await collectEvidence(state, event, ctx);
  });

  // 内层 tick —— 唯一安全的判定点
  pi.on("agent_settled", async (_e, ctx) => {
    if (!state) return;
    const verdict = await evaluate(state, ctx);
    pi.appendEntry("loop-verdict", verdict);        // 不进 LLM 上下文

    if (verdict.pass)            return advance(state, pi);
    if (shouldEscalate(state))   return pi.sendUserMessage("/loop escalate", { deliverAs: "followUp" });
    return retry(state, pi);
  });

  pi.registerCommand("loop", { description: "双层循环工作流", handler: loopCommand });
}
```
