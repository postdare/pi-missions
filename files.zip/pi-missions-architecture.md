# pi-missions · 架构方案

> 一套跑在 pi coding agent 上的双层循环工作流引擎。
> 外层 PDCA 管任务分解与进度追踪,内层操控循环管执行中的质量控制与自我修正。
> 提供 quick / standard / complex 三档。
>
> 扩展包名:`pi-missions` · 命令空间:`/missions` `/mission`

---

## 0. 设计不变量

前五条是双层循环自身的地基,后四条来自驾驭工程六大实践。任何一条被绕过,系统都会退化成"带仪式感的单层循环"。

| # | 不变量 | 违反后果 |
|---|---|---|
| **I1** | 状态是仓库里的文件,不是会话里的对话 | 会话一断/一压缩,进度全丢 |
| **I2** | 验收标准在 Plan 阶段冻结,执行期只读 | agent 做不出来就悄悄放宽标准 |
| **I3** | 判定"对了/错了"的证据必须来自执行者之外 | Check 变成自我表扬 |
| **I4** | 熔断优先于重试:同一问题连续失败必须升级,不得继续微调 | 在错误方案上无限打磨 |
| **I5** | 每次升级必须换干净上下文 | 在被污染的上下文里"重新思考",只得到同一错误的变体 |
| **I6** | 不在仓库里的,对 Agent 等于不存在 | 换机器/换 agent 行为不一致,不可追溯 |
| **I7** | 确定性判定归代码,语义判断归模型;能不调模型就不调 | 用超算算小学数学,又慢又贵 |
| **I8** | 上下文按相位分层加载,走到哪一步读哪一层 | 注意力被稀释,跳步骤、漏子任务 |
| **I9** | 环境不一致时判 INCONCLUSIVE,不判 FAIL | 环境漂移触发无效熔断,升级到错误的层 |

---

## 1. 总体分层

```
┌─────────────────────────────────────────────────────────────┐
│  L0  控制面(Extension 进程内 · 零模型成本)                  │
│      Phase Machine · Circuit Breaker · Gate · Verdict        │
│      —— 纯 TypeScript,是唯一的裁判                          │
└───────────────┬─────────────────────────────────────────────┘
                │ 读写
┌───────────────▼─────────────────────────────────────────────┐
│  L1  状态面(仓库内,受 git 版本控制)                        │
│      missions/plans/**  ·  missions/state/**                 │
└───────────────┬─────────────────────────────────────────────┘
                │ 按相位分层注入
┌───────────────▼─────────────────────────────────────────────┐
│  L2  执行面                                                  │
│      主会话:Plan / Do / Act(会话替换换脑)                  │
│      子进程:Check worker(独立上下文 + 独立模型)            │
└───────────────┬─────────────────────────────────────────────┘
                │ 采集
┌───────────────▼─────────────────────────────────────────────┐
│  L3  证据面                                                  │
│      hard:编译/测试/lint/类型检查退出码(纯代码,零成本)     │
│      semi:AC 逐条核对(Check worker)                        │
│      soft:执行者自述(只能触发 ACT,不能触发 PASS)          │
└─────────────────────────────────────────────────────────────┘
```

**L0 是裁判,L2 只是执行者。** LLM 永远不能自己宣布"我做完了",它只能提交,由 L0 依据 L3 判定。

---

## 2. 仓库布局(I6 · 仓库即规范)

状态**不放 `.pi/`**——那是工具目录,通常在 `.gitignore` 里。全部进仓库:

```
<repo>/
├── AGENTS.md                          # 入口:只写核心规则 + 路径指引
├── missions/
│   ├── README.md                      # 工作流规则(Agent-first,不迁就人类阅读)
│   ├── phases/                        # 相位提示词,进入该相位才加载
│   │   ├── plan.md
│   │   ├── do.md
│   │   ├── check.md
│   │   └── act.md
│   ├── scripts/
│   │   ├── verify.sh                  # AC 的唯一执行入口(见 §8.6)
│   │   └── env-fingerprint.sh         # 环境指纹
│   ├── plans/
│   │   └── auth-refactor/
│   │       ├── MISSION.md             # 目标 + 冻结 AC + 里程碑索引
│   │       ├── M1.md                  # complex 档:里程碑分文件(I8)
│   │       └── M2.md
│   └── state/
│       └── auth-refactor/
│           ├── STATE.json
│           ├── LOG.md
│           └── evidence/
│               └── T3-attempt2.json
└── .pi/extensions/pi-missions/        # 扩展代码(可选:项目级安装)
```

### AC 冻结的物理实现

原方案靠扩展代码拦截写操作——**这拦不住**,agent 有 bash,绕过只是时间问题。放进 git 后冻结变成社会约束 + 机械约束:

- AC 的任何修改必须是单独一次 commit,message 前缀 `mission-escalate(L3):`
- pre-commit hook 校验:若 diff 触及 `MISSION.md` 的 `## Frozen Acceptance Criteria` 段落而 message 无该前缀,拒绝提交
- 改了什么、为什么改、结果如何全在 `git log` 里,不靠 LOG.md 自证

### MISSION.md

```markdown
# Mission: auth-refactor
tier: standard
goal: 把登录鉴权从 session 迁移到 JWT,不影响现有接口契约

## Frozen Acceptance Criteria
> 本节只读。修改必须走 /mission escalate --level=3,并以 mission-escalate(L3): 提交。

- AC1: `./missions/scripts/verify.sh auth-integration` 退出码 0
- AC2: `./missions/scripts/verify.sh contract-snapshot` 退出码 0
- AC3: `./missions/scripts/verify.sh checkstyle` 退出码 0

## Tasks
- [ ] T1 引入 JwtProvider 与配置   (verify: compile)
- [ ] T2 替换 SessionAuthFilter    (verify: auth-filter)
- [ ] T3 迁移登录/登出端点         (verify: auth-integration)
- [ ] T4 契约回归                  (verify: contract-snapshot, checkstyle)
```

**AC 不写裸命令,写锁定入口。** 裸 `mvn -q test …` 在不同机器上语义不同,而 `verify.sh` 连同锁文件一起进仓库,是可复现的(I9,详见 §8.6)。

### STATE.json

```jsonc
{
  "missionId": "auth-refactor",
  "tier": "standard",
  "phase": "do",                    // plan | do | check | act | done | halted
  "currentTask": "T3",
  "tasks": {
    "T1": { "status": "done",    "attempts": 1 },
    "T2": { "status": "done",    "attempts": 2 },
    "T3": { "status": "running", "attempts": 2,
            "lastFailure": "AuthIntegrationTest#refreshToken assertion" }
  },
  "escalation": { "level": 1, "history": [] },
  "envFingerprint": "sha256:9f2c…",
  "sessionMap": { "T3": ".pi/sessions/xxx.jsonl" },
  "cost": { "plan": 0.42, "do": 1.87, "check": 0.09 },   // 按角色累计
  "updatedAt": 1756600000000
}
```

`cost` 按角色分账,是后续调模型策略的唯一依据。

### LOG.md

排障时唯一要读的文件。一条一行,不写散文:

```
2026-08-31T10:22 T3 a=1 verdict=FAIL ev=refreshToken断言 act=fix-impl
2026-08-31T10:41 T3 a=2 verdict=FAIL ev=同一断言    act=fix-impl
2026-08-31T11:03 T3 a=3 verdict=FAIL ev=同一断言    act=ESCALATE→L2 why=连续3次同一签名
2026-08-31T11:05 T3 L2: 方案假设错误 —— refresh token 不应复用同一密钥
```

---

## 3. 相位状态机

```
                 ┌──────────────────────────────────────┐
                 │                                      │
   ┌──────┐      ▼      ┌──────┐  submit  ┌───────┐     │
   │ PLAN │──freeze──▶ │  DO  │─────────▶│ CHECK │     │
   └──────┘             └──────┘           └───┬───┘     │
       ▲                   ▲                   │         │
       │                   │  PASS ┌───────────┴───┐FAIL │
       │                   │       ▼               ▼     │
       │                   │  next task ──▶   ┌─────┐    │
       │                   └──────────────────│ ACT │────┘
       │                    attempts < N      └──┬──┘
       └──────────── ESCALATE(L2/L3)◀───────────┘
```

### 相位 → 能力矩阵

L0 在相位切换时用 `pi.setActiveTools()` 改写工具集,这是闸门的物理实现:

| 相位 | 可用工具 | 可写文件 | 加载的上下文层 |
|---|---|---|---|
| PLAN | `read` `grep` `find` `ls` `mission_write_plan` | 仅 MISSION.md | `phases/plan.md` |
| DO | 全部 + `mission_submit` | 是 | `phases/do.md` + 当前任务 |
| CHECK | (子进程,见 §6) | 否 | `phases/check.md` + AC + diff |
| ACT | `read` `grep` `mission_escalate` | 否 | `phases/act.md` + LOG 该任务段 |

> CHECK 禁写是 I3 的实现:验证者一旦能改代码,就会"顺手修一下"然后判自己通过。

---

## 4. 角色与模型策略(I7 · 成本优化核心)

四类角色,成本性质完全不同。Factory Missions 的做法是编排器保持 model-agnostic、每个角色配最合适的模型——这里照搬,但多加一层:**最便宜的角色是根本不调模型**。

| 角色 | 性质 | 频次 | 建议配置 | 成本量级 |
|---|---|---|---|---|
| **Judge**(L0 裁判) | 确定性 | 极高 | 纯代码,无模型 | **0** |
| **Planner** | 推断型 | 低 | 强模型 + thinking=high | 高单价 × 少次 |
| **Executor**(Do) | 混合 | 高 | 中档模型 + thinking=medium | 主要开销 |
| **Verifier**(Check) | 机械核对 | 中 | 便宜模型 + thinking=off | 低单价 × 中次 |
| **Escalator**(Act) | 推断型 | 低 | 强模型 + thinking=high | 高单价 × 极少 |

配置放仓库(I6):`missions/models.json`

```jsonc
{
  "planner":    { "provider": "anthropic", "model": "…", "thinking": "high" },
  "executor":   { "provider": "anthropic", "model": "…", "thinking": "medium" },
  "verifier":   { "provider": "…",         "model": "…", "thinking": "off" },
  "escalator":  { "provider": "anthropic", "model": "…", "thinking": "high" }
}
```

主会话的角色切换用 `pi.setModel()` + `pi.setThinkingLevel()`,在相位迁移时执行。Verifier 跑在子进程,用 `--model` 传参。

**省钱的真正来源不是换小模型,是三件事:**

1. **hard 证据零模型**。编译/测试/lint 的退出码由代码判定。理想比例是代码承担 60–70% 的检查——你做 Java 后端,这个比例应该更高,不要为了凑比例把该给代码的判断硬塞给模型。
2. **Verifier 不带 Do 的对话历史**。它只需要 AC + diff + 测试输出,通常几千 token,而 Do 会话此时可能已有十万级上下文。
3. **换脑而非压缩**。auto-compact 是有损的且要额外调一次模型;换脑无损(状态在仓库里)且不花模型钱。

---

## 5. 三档工作流

三档的差别只在两个维度:**是否落 MISSION.md,以及换脑的粒度**。不要为每档发明新概念。

| | quick | standard | complex |
|---|---|---|---|
| 入口 | `/mission quick <任务>` | `/mission new <目标>` | `/mission new --tier=complex` |
| MISSION.md | 不落盘(AC 存内存) | 落盘,任务级 | 落盘,里程碑分文件 |
| 分解粒度 | 单任务 | 任务列表 | milestone → task |
| Verifier | 仅 hard 证据 | hard + 子进程 semi | hard + 子进程 semi + 里程碑回归 |
| 换脑粒度 | 不换 | 水位触发 | 每任务换 + 每里程碑收敛 |
| 熔断阈值 N | 2 | 3 | 3(里程碑级另计) |

### 升档自动,降档手动

这条比分档规则本身重要,它防止 agent 在小任务里死磕:

```ts
if (tier === "quick"    && attempts >= 2)                  promoteTo("standard");
if (touchedFiles.size > 5 || touchedPublicApi)             promoteTo("standard");
if (tier === "standard" && milestoneDrift())               promoteTo("complex");
```

判据必须机械可测:**改动文件数、是否触及接口或数据模型、是否可逆、是否有既有测试覆盖**。不要让 LLM 自评"这个任务复杂吗"。

---

## 6. Subagent 决策

**pi 不提供 subagent**,它明确跳过了 subagent 和 plan mode,留给扩展。本方案在两种隔离方式中做了区分选择:

| | 会话替换 | 子进程 worker |
|---|---|---|
| 机制 | `ctx.newSession()` / `switchSession()` | `pi.exec("pi", ["-p", …])` |
| 隔离 | 完全(旧会话被替换) | 完全(独立进程) |
| 回程 | 需切回,缓存前缀失效 | 无需回程,返回即结束 |
| 用于 | Plan → Do → Act 的相位迁移 | **Check** |

**Check 用子进程,理由是它不需要回程。** Verifier 只输出一个 verdict,不需要继续对话,也不需要 Do 的历史。这让它成为最干净的一次隔离:

```ts
const { stdout, code } = await pi.exec("pi", [
  "-p",                                     // print 模式,单次输出
  "--mode", "json",
  "--model", models.verifier.model,
  "--no-builtin-tools",                     // 只给它 read + bash
  "-e", "./missions/verifier-tools.ts",
], { input: renderVerifierBrief(mission, diff, evidence), signal });
```

`verifier-tools.ts` 只注册一个 `mission_verdict` 工具,用 `terminate: true` 让它在提交结论后立即结束——这正是 pi structured-output 的推荐模式。

**v0.1 不做子进程**,先用主会话 + 硬证据。子进程 Verifier 属于 v0.2。

---

## 7. TUI 交互

### 7.1 `/missions` 主面板

用 `ctx.ui.custom()`(需 `ctx.mode === "tui"` 守卫)渲染。顶部新建,下方历史,与 Factory 的 Mission Control 同构:

```
┌─ Missions ─────────────────────────────────────────────────┐
│                                                            │
│  ▸ + 新建任务                                              │
│      quick     单任务,不落盘,快速循环                    │
│      standard  任务列表 + 验证闸门          ← 默认         │
│      complex   里程碑 + 独立验证 + 逐里程碑回归            │
│                                                            │
│  ─────────────────────────────────────────────────────     │
│                                                            │
│  ● auth-refactor          standard  T3/4  a2/3   进行中    │
│      迁移登录鉴权到 JWT                                    │
│      ⚠ 同一失败签名 ×2,再失败一次将升级到 L2              │
│                                                            │
│  ○ coupon-batch-fix       quick     —      a1/2   已完成   │
│      2026-08-29 · 12min · $0.31                            │
│                                                            │
│  ✕ mybatis-upgrade        complex   M2/3  a3/3   已熔断    │
│      2026-08-27 · L3 未确认                                │
│                                                            │
│  ↑↓ 选择   ⏎ 打开   n 新建   d 详情   r 恢复   q 退出      │
└────────────────────────────────────────────────────────────┘
```

历史列表从 `missions/state/*/STATE.json` 扫描重建,不依赖内存。`⏎` 打开进行中的任务 = `switchSession` 回到它的会话;打开已完成的 = 只读展示 LOG.md。

### 7.2 常驻状态条

`ctx.ui.setWidget("missions", …)`,始终显示在编辑器上方:

```
◆ auth-refactor · standard · T3 迁移登录端点 · phase=do · attempt 2/3 · executor
```

熔断临界(`attempts === N-1`)时整行转 warning 色。这是 I4 的可视化——你需要在它烧断之前就看见。

### 7.3 事件卡片

verdict 和升级事件用 `pi.appendEntry()` + `registerEntryRenderer()` 渲染。**关键:这些不进 LLM 上下文**,只在 TUI 可见,所以可以写得详细而不消耗窗口:

```
  ✕ CHECK FAILED  T3 · attempt 2
    AC1  ✕  AuthIntegrationTest#refreshToken:87  expected 200 but was 401
    AC2  ✓  contract-snapshot
    AC3  ✓  checkstyle
    → 失败签名与 attempt 1 相同,再失败一次将升级到 L2
    ⏎ 展开完整输出
```

### 7.4 人在回路的位置

按最小干预原则,人只在这三处被打断,其余全自动:

1. **PLAN 冻结前**——`ctx.ui.confirm` 确认 AC。这是最重要的一次介入,后面所有判定都依赖它。
2. **L3 升级前**——修改冻结 AC 必须人工确认。
3. **熔断停机**——L3 也失败后进入 `halted`,`ctx.ui.notify` 提示并停止,不再自动重试。

L1/L2 升级不打断人。每轮人工检查的真实成本是上下文切换,次数一多多数人会放弃参与、盲目接受结果——那比不参与更糟。

---

## 8. 关键机制

### 8.1 证据分级(I3)

```ts
type Verdict = {
  level: "hard" | "semi" | "soft";
  result: "pass" | "fail" | "inconclusive";
  evidence: string;
  signature?: string;
};
```

判定优先级:任一 hard fail → FAIL。任一 inconclusive → INCONCLUSIVE(**不计入熔断**)。全部 hard pass 且 semi pass → PASS。其余 → ACT。

soft 证据只能触发 ACT,不能触发 PASS。

### 8.2 编辑级反馈(最小干预)

lint、类型检查、LSP 诊断是**每次编辑后立刻可得**的,没理由攒到 CHECK。在 `tool_result` 里对每次 `edit`/`write` 后台跑增量检查,发现问题当场回灌:

```ts
pi.on("tool_result", async (event, ctx) => {
  if (!["edit", "write"].includes(event.toolName)) return;
  const diag = await runIncrementalCheck(event.input.path, ctx.signal);
  if (diag.length) {
    pi.sendMessage({
      customType: "missions-diagnostic",
      content: renderDiagnostics(diag),
      display: true,
    }, { deliverAs: "steer" });     // 当前 turn 的工具跑完后立即送达
  }
});
```

内层循环的粒度从"任务级"降到"编辑级"。这才是真正的最小干预——问题在到达人眼之前就自我纠正。

### 8.3 熔断与升级阶梯(I4)

```ts
const signature = hash(normalize(evidence));   // 见 §12.3
if (sameSignatureCount >= N) escalate();       // 不是再试一次,是换一层问题
```

三级阶梯,**每次只升一级**:

| 级别 | 动作 | 换脑 | 角色 | 产物 |
|---|---|---|---|---|
| L1 | 改实现 | 否 | executor | 新的 attempt |
| L2 | 改方案 → 回 PLAN | 是 | escalator | Tasks 段重写(AC 不变) |
| L3 | 改问题定义 | 是 | escalator | MISSION.md 重写,旧版归档 + 人工确认 |

**升级时携带的上下文只有三样**:MISSION.md、LOG.md 中该任务的失败记录、最后一次失败证据。**不携带失败会话的原始对话**——那正是要丢掉的污染源。

### 8.4 换脑机制(I5)⚠️ 实现陷阱

`ctx.newSession()` / `fork()` / `switchSession()` 属于 `ExtensionCommandContext`,**只在命令处理器中可用**;事件处理器里调用会死锁。所以换脑必须绕一圈:

```
agent_settled(事件) 判定需要换脑
   └─▶ pi.sendUserMessage("/mission next", { deliverAs: "followUp" })
          └─▶ /mission next(命令) 中执行 ctx.newSession(…)
```

```ts
pi.registerCommand("mission", {
  handler: async (args, ctx) => {
    const brief = renderTaskBrief(state);        // ✅ 只捕获纯数据

    await ctx.newSession({
      parentSession: ctx.sessionManager.getSessionFile(),
      setup: async (sm) => {
        sm.appendMessage({ role: "user",
          content: [{ type: "text", text: brief }], timestamp: Date.now() });
      },
      withSession: async (ctx2) => {
        await ctx2.sendUserMessage("开始执行当前任务");   // ⚠️ 必须用 ctx2
      },
    });
    return;                                       // 换脑视为该 handler 终点
  },
});
```

❌ `withSession` 内绝不能用外层捕获的 `pi`、`ctx`,或提前抽出的 `ctx.sessionManager`——会话替换后它们已失效并会抛错。

### 8.5 渐进式披露(I8)

四层,走到哪一步读哪一层:

```
AGENTS.md(常驻,只写规则和指路)
  → missions/phases/do.md(进入 DO 才读)
    → missions/plans/<id>/M2.md(complex 档,到第 2 个里程碑才读)
      → missions/state/<id>/STATE.json(执行时才读写)
```

用 `resources_discover` 按相位动态贡献 `skillPaths`,比硬编码提示词更贴合 pi 的机制:

```ts
pi.on("resources_discover", async () => ({
  skillPaths: [`./missions/phases/${state.phase}`],
}));
```

**complex 档的计划必须按里程碑拆文件**,否则做 M1 时 M3 的任务描述一直在稀释注意力。

注入主会话的 State Card 保持极简:

```
[MISSION] auth-refactor · standard · phase=do · task=T3 · attempt=2/3
GOAL: 迁移登录/登出端点到 JWT
AC(冻结,不可修改):
  - AC1: ./missions/scripts/verify.sh auth-integration 退出码 0
PREV FAILURE: AuthIntegrationTest#refreshToken 断言失败
你只需完成 T3。完成后调用 mission_submit,不要自行判定通过。
```

最后一句是刚需——否则 LLM 会自己宣布完成然后开始做 T4。

### 8.6 可复现性(I9)

这条不做,会直接反噬整个判定体系:同一条 AC 在你机器上绿、在 CI 上红,系统判 FAIL → 触发熔断 → 升级到 L2 让 agent 改方案,但**病根在环境**。这是最难排查的一类假阳性。

三件事:

1. **AC 只准调 `verify.sh`**,不准写裸命令。脚本连同锁文件(`pom.xml` / `requirements.txt` / `package-lock.json`)一起进仓库。
2. **环境指纹**:`env-fingerprint.sh` 输出 JDK / Maven / Node 版本 + 锁文件 hash,写入 STATE.json,并随每份 evidence 存档。
3. **指纹不一致 → INCONCLUSIVE**,不计入熔断计数,TUI 明确提示"环境已变更"。

> 一句话:用得好好的 agent 无端变差,除了怀疑提示词和模型,先检查环境。

---

## 9. 命令集

`/missions`(复数)= 面板,`/mission`(单数)= 动作。pi 在命令重名时会自动加数字后缀,这个划分能避开常见冲突。

| 命令 | 作用 |
|---|---|
| `/missions` | **主面板**:顶部新建,下方历史列表 |
| `/mission new <目标> [--tier=…]` | 新建并进入 PLAN 相位 |
| `/mission quick <任务>` | quick 档快捷入口,跳过 PLAN 落盘 |
| `/mission status` | 当前任务详情(相位/尝试/证据摘要) |
| `/mission next` | 推进到下一任务 —— **换脑的唯一入口** |
| `/mission verify` | 手动触发一次 CHECK |
| `/mission escalate [--level=2\|3]` | 主动升级 |
| `/mission plan` | 打开 MISSION.md 编辑(仅 PLAN 相位) |
| `/mission log [--task=T3]` | 查看 LOG.md |
| `/mission resume <id>` | 恢复历史任务 |
| `/mission abort` | 终止当前任务,状态置 halted |
| `/mission models` | 查看/切换角色模型映射,显示本次分角色花费 |

`/mission next` `/mission escalate` 主要由 L0 通过 `sendUserMessage(…, { deliverAs: "followUp" })` 内部调用,人也可以手动敲。

### LLM 可调用的工具(仅四个)

| 工具 | 相位 | 作用 |
|---|---|---|
| `mission_write_plan` | PLAN | 写入 MISSION.md;写入即冻结 AC |
| `mission_submit` | DO | 声明已提交,触发 CHECK(**不等于通过**) |
| `mission_verdict` | CHECK | 提交逐条 AC 核对结果(子进程内) |
| `mission_escalate` | ACT | 主动请求升级,附理由 |

工具越少越好。状态推进由 L0 驱动,**不给 LLM 直接改 STATE.json 的工具**。

---

## 10. 代码结构

```
pi-missions/
├── package.json                 # { "pi": { "extensions": ["./src/index.ts"] } }
└── src/
    ├── index.ts                 # 装配:注册命令/工具/事件
    ├── core/                    # ⚠️ 纯函数 + 必须有单测
    │   ├── machine.ts           # 相位状态机
    │   ├── breaker.ts           # 失败签名 + 熔断 + 升级阶梯
    │   ├── verdict.ts           # 证据分级与判定
    │   └── tier.ts              # 分档与自动升档规则
    ├── store/
    │   ├── mission.ts           # MISSION.md 读写 + AC 冻结校验
    │   ├── state.ts             # STATE.json(withFileMutationQueue 保护)
    │   ├── log.ts               # LOG.md 追加
    │   └── scan.ts              # 扫描 missions/state/* 重建历史列表
    ├── roles/
    │   ├── models.ts            # models.json + setModel/setThinkingLevel
    │   └── verifier.ts          # 子进程 Check worker
    ├── hooks/
    │   ├── gate.ts              # tool_call 闸门
    │   ├── evidence.ts          # tool_result 证据采集 + 编辑级反馈
    │   ├── tick.ts              # agent_settled 内层 tick
    │   └── resources.ts         # resources_discover 分层加载
    └── ui/
        ├── panel.ts             # /missions 主面板(ctx.ui.custom)
        ├── widget.ts            # 常驻状态条
        └── renderer.ts          # verdict / escalate 卡片
```

`core/` 四个文件是唯一的裁判,**不能靠"跑一遍看看对不对"来验证**——否则排障时你分不清是 agent 错了还是裁判错了。

---

## 11. 实施路线

**v0.1 — standard 档 + 熔断 + 可复现**(1~2 天)

- 仓库布局 + MISSION.md / STATE.json / LOG.md
- 相位状态机 + `tool_call` 闸门
- hard 证据采集(`verify.sh` 退出码)+ 环境指纹
- 熔断计数 + L2 升级
- 常驻状态条
- 不做:TUI 面板、子进程 Verifier、换脑、quick/complex

跑 2~3 个真实任务,记录四个数:**内层平均迭代次数、熔断触发率、触发时病根在哪一层、INCONCLUSIVE 占比**。

**v0.2 — 隔离与模型策略**

- `/mission next` + `newSession` 换脑
- 子进程 Verifier + `models.json` 角色模型
- 编辑级增量反馈
- L3 + 人工确认
- 上下文水位守卫(超 50% 主动换脑,而非等 auto-compact)

**v0.3 — TUI 与分档**

- `/missions` 主面板
- 从 v0.1/v0.2 数据反推 quick 砍什么、complex 加什么
- complex 的里程碑验证

> 分档规则应该从数据里长出来,不是先想好的。三档 × 双层 × 多角色一次性做,几乎必然过度设计。

---

## 12. 已知风险

1. **相位提示词与 pi 内置 systemPrompt 冲突。** `before_agent_start` 是链式的,你的修改可能被后加载的扩展覆盖。把 pi-missions 放在加载顺序末位,用 `ctx.getSystemPrompt()` 自检。

2. **并行工具执行下的 `tool_call` 时序。** pi 默认并行执行工具,`tool_call` 不保证能看到同批次兄弟工具的结果。闸门只依赖 STATE,不依赖"上一个工具的结果"。

3. **失败签名的归一化粒度 —— 最需要按实际数据调的参数。** 太严则同一病根算作不同失败(熔断永不触发),太松则误熔断。起步只取测试类名 + 方法名 + 断言类型,忽略行号与堆栈。

4. **换脑成本。** 每次换脑要重新读代码建立理解。standard 档"每任务换一次"可能过于激进,v0.1 先只用水位触发,观察实际收益。

5. **子进程 Verifier 的启动开销。** 每次 CHECK 都起一个 pi 进程,冷启动成本在小任务上可能不划算。quick 档不用它是对的。

6. **串行优先。** Factory 的公开经验是串行执行 + 定点并行优于大面积并行。本方案默认全串行,不要过早引入多 worker。

7. **六大实践没覆盖熔断和换脑。** 那篇文章是单 agent harness 视角,内层循环默认能自己收敛;"在错误方案上反复微调"这个失败模式它没讨论。§8.3 / §8.4 是在六条之外补的,不是从中推导出来的。

---

## 附:index.ts 骨架

```ts
import type { ExtensionAPI } from "@earendil-works/pi-coding-agent";
import { loadState } from "./store/state";
import { toolsForPhase } from "./hooks/gate";
import { applyRole } from "./roles/models";
import { evaluate } from "./core/verdict";
import { shouldEscalate } from "./core/breaker";

export default function (pi: ExtensionAPI) {
  let state = null;                          // 内存镜像,仓库为准

  pi.on("session_start", async (_e, ctx) => {
    state = await loadState(ctx.cwd);
    if (!state) return;
    pi.setActiveTools(toolsForPhase(state.phase));
    await applyRole(pi, state.phase);        // setModel + setThinkingLevel
    ctx.ui.setWidget("missions", [renderStatus(state)]);
  });

  // 按相位分层加载上下文(I8)
  pi.on("resources_discover", async () =>
    state ? { skillPaths: [`./missions/phases/${state.phase}`] } : undefined);

  // 注入 State Card
  pi.on("before_agent_start", async (event) => {
    if (!state) return;
    return {
      message: { customType: "missions-state", content: renderCard(state), display: true },
      systemPrompt: `${event.systemPrompt}\n\n${phaseRules(state.phase)}`,
    };
  });

  // 闸门
  pi.on("tool_call", async (event) => {
    if (!state) return;
    const denied = gateCheck(state.phase, event.toolName, event.input);
    if (denied) return { block: true, reason: denied };
  });

  // 证据采集 + 编辑级反馈
  pi.on("tool_result", async (event, ctx) => {
    if (!state) return;
    await collectEvidence(state, event, ctx);
    await pushIncrementalDiagnostics(pi, event, ctx);
  });

  // 内层 tick —— 唯一安全的判定点
  pi.on("agent_settled", async (_e, ctx) => {
    if (!state) return;
    const verdict = await evaluate(state, ctx);      // hard 走代码,semi 起子进程
    pi.appendEntry("missions-verdict", verdict);     // 不进 LLM 上下文

    if (verdict.result === "inconclusive") return warnEnvDrift(ctx, verdict);
    if (verdict.result === "pass")         return advance(state, pi);
    if (shouldEscalate(state))
      return pi.sendUserMessage("/mission escalate", { deliverAs: "followUp" });
    return retry(state, pi);
  });

  pi.registerCommand("missions", { description: "任务面板", handler: openPanel });
  pi.registerCommand("mission",  { description: "任务操作", handler: missionCommand });
}
```
