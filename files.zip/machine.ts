/**
 * pi-missions · core/machine
 *
 * 相位状态机。纯 reducer:(state, event) → { state, effects }
 *
 * 机器本身不执行任何副作用,只产出 Effect 清单交给 hooks 层翻译成 pi API 调用。
 * 这是 core 能被单测的前提,也是"L0 是唯一裁判"的物理保证。
 *
 *                 ┌──────────────────────────────────────┐
 *                 │                                      │
 *   ┌──────┐      ▼      ┌──────┐  submit  ┌───────┐     │
 *   │ PLAN │──freeze──▶ │  DO  │─────────▶│ CHECK │     │
 *   └──────┘             └──────┘           └───┬───┘     │
 *       ▲                   ▲                   │         │
 *       │                   │  PASS ┌───────────┴───┐FAIL │
 *       │                   │       ▼               ▼     │
 *       │                   │  next task ──▶   ┌─────┐    │
 *       │                   └──────────────────│ ACT │────┘
 *       │                    ADJUST_DONE       └──┬──┘
 *       └──────────── ESCALATE(L2/L3)◀───────────┘
 */

import type {
  Effect,
  MissionEvent,
  MissionState,
  Phase,
  Role,
  TaskState,
  TransitionResult,
  Tier,
} from "./types.ts";
import { resetAfterEscalation } from "./breaker.ts";

const ROLE_OF: Record<Phase, Role | null> = {
  plan: "planner",
  do: "executor",
  check: "verifier",
  act: "escalator",
  done: null,
  halted: null,
};

/**
 * 换脑策略。I5 要求"每次升级必须换干净上下文",这条无条件成立。
 * 任务切换是否换脑则按档位:只有 complex 强制换,其余交给上下文水位触发。
 */
function shouldHandoffOnAdvance(tier: Tier): boolean {
  return tier === "complex";
}

export function transition(state: MissionState, event: MissionEvent): TransitionResult {
  switch (event.type) {
    // ─────────────── 任意相位都可中止 ───────────────
    case "ABORT":
      if (state.phase === "halted" || state.phase === "done") {
        return reject(state, `已处于 ${state.phase},忽略 ABORT`);
      }
      return {
        state: { ...state, phase: "halted" },
        effects: [
          log(`ABORT ${event.reason}`),
          { type: "NOTIFY", level: "warning", message: `任务已终止:${event.reason}` },
        ],
      };

    // ─────────────── PLAN → DO ───────────────
    case "PLAN_FROZEN": {
      if (state.phase !== "plan") return reject(state, `PLAN_FROZEN 只能在 plan 相位`);
      const first = state.taskOrder[0];
      if (!first) return reject(state, "计划中没有任务,无法进入 DO");

      const tasks = setTask(state.tasks, first, (t) => ({
        ...t,
        status: "running",
        attempts: 1,
      }));

      return {
        state: { ...state, phase: "do", currentTask: first, tasks },
        effects: [
          { type: "FREEZE_AC" },
          ...enter("do"),
          log(`PLAN frozen, start ${first} attempt=1`),
        ],
      };
    }

    // ─────────────── DO → CHECK ───────────────
    case "SUBMIT": {
      if (state.phase !== "do") return reject(state, "SUBMIT 只能在 do 相位");
      if (!state.currentTask) return reject(state, "无当前任务");
      return {
        state: { ...state, phase: "check" },
        effects: [...enter("check"), log(`${state.currentTask} submitted, verifying`)],
      };
    }

    // ─────────────── CHECK → DO / ACT / DONE ───────────────
    case "VERDICT": {
      if (state.phase !== "check") return reject(state, "VERDICT 只能在 check 相位");
      const taskId = state.currentTask;
      if (!taskId) return reject(state, "无当前任务");
      const task = state.tasks[taskId];
      const attempt = task?.attempts ?? 1;

      // 环境漂移等无结论情况:回 DO,不计 attempts,不进熔断
      if (event.verdict.outcome === "inconclusive") {
        return {
          state: { ...state, phase: "do" },
          effects: [
            ...enter("do"),
            log(`${taskId} a=${attempt} verdict=INCONCLUSIVE why=${event.verdict.reason}`),
            {
              type: "NOTIFY",
              level: "warning",
              message: `无法判定(不计入熔断):${event.verdict.reason}`,
            },
          ],
        };
      }

      if (event.verdict.outcome === "fail") {
        return {
          state: { ...state, phase: "act" },
          effects: [
            ...enter("act"),
            log(
              `${taskId} a=${attempt} verdict=FAIL sig=${event.verdict.signature ?? "-"} ` +
                `ev=${compact(event.verdict.reason)}`,
            ),
          ],
        };
      }

      // PASS —— 推进到下一任务,或整体完成
      const doneTasks = setTask(state.tasks, taskId, (t) => ({ ...t, status: "done" }));
      const next = nextTask(state.taskOrder, taskId);

      if (!next) {
        return {
          state: { ...state, phase: "done", currentTask: null, tasks: doneTasks },
          effects: [
            log(`${taskId} a=${attempt} verdict=PASS · mission done`),
            { type: "NOTIFY", level: "info", message: "全部任务完成" },
          ],
        };
      }

      const tasks = setTask(doneTasks, next, (t) => ({
        ...t,
        status: "running",
        attempts: 1,
      }));

      const effects: Effect[] = [
        log(`${taskId} a=${attempt} verdict=PASS → ${next}`),
        { type: "ADVANCE_TASK", taskId: next },
      ];
      if (shouldHandoffOnAdvance(state.tier)) {
        effects.push({ type: "HANDOFF", reason: `advance to ${next}` });
      }
      effects.push(...enter("do"));

      return { state: { ...state, phase: "do", currentTask: next, tasks }, effects };
    }

    // ─────────────── ACT → DO(L1 重试) ───────────────
    case "ADJUST_DONE": {
      if (state.phase !== "act") return reject(state, "ADJUST_DONE 只能在 act 相位");
      const taskId = state.currentTask;
      if (!taskId) return reject(state, "无当前任务");

      const tasks = setTask(state.tasks, taskId, (t) => ({ ...t, attempts: t.attempts + 1 }));
      const attempt = tasks[taskId].attempts;

      return {
        state: { ...state, phase: "do", tasks },
        effects: [...enter("do"), log(`${taskId} retry attempt=${attempt}`)],
      };
    }

    // ─────────────── ACT → PLAN(L2/L3 升级) ───────────────
    case "ESCALATE": {
      if (state.phase !== "act") return reject(state, "ESCALATE 只能在 act 相位");
      const taskId = state.currentTask;
      if (!taskId) return reject(state, "无当前任务");
      if (event.to <= state.escalation.level) {
        return reject(state, `不能从 L${state.escalation.level} 降级到 L${event.to}`);
      }

      const record = {
        at: event.at,
        taskId,
        from: state.escalation.level,
        to: event.to,
        signature: state.tasks[taskId]?.lastSignature,
        reason: event.reason,
      };

      // L3 要改冻结 AC,必须人工确认。状态先不迁移,等 CONFIRMED/REJECTED。
      if (event.to === 3) {
        return {
          state: {
            ...state,
            escalation: { level: 3, history: [...state.escalation.history, record] },
          },
          effects: [
            log(`${taskId} ESCALATE→L3 why=${compact(event.reason)} (待人工确认)`),
            {
              type: "CONFIRM",
              question: `L3 升级将重写问题定义并修改冻结的验收标准。\n理由:${event.reason}\n确认继续?`,
            },
          ],
        };
      }

      // L2:重写方案,AC 不变。立刻换脑 —— 在被污染的上下文里重新规划毫无意义。
      const tasks = setTask(state.tasks, taskId, resetAfterEscalation);
      return {
        state: {
          ...state,
          phase: "plan",
          tasks,
          escalation: { level: 2, history: [...state.escalation.history, record] },
        },
        effects: [
          log(`${taskId} ESCALATE→L2 why=${compact(event.reason)}`),
          { type: "HANDOFF", reason: `escalate L2 on ${taskId}` },
          ...enter("plan"),
        ],
      };
    }

    case "ESCALATION_CONFIRMED": {
      if (state.escalation.level !== 3) return reject(state, "当前无待确认的 L3 升级");
      const taskId = state.currentTask;
      const tasks = taskId ? setTask(state.tasks, taskId, resetAfterEscalation) : state.tasks;
      return {
        state: { ...state, phase: "plan", tasks },
        effects: [
          log(`L3 confirmed, rewriting mission definition`),
          { type: "ARCHIVE_PLAN", reason: "L3 escalation" },
          { type: "HANDOFF", reason: "escalate L3" },
          ...enter("plan"),
        ],
      };
    }

    case "ESCALATION_REJECTED":
      return {
        state: { ...state, phase: "halted" },
        effects: [
          log("L3 rejected by human, halted"),
          { type: "NOTIFY", level: "warning", message: "已停机。任务状态保留在仓库中,可 /mission resume 恢复。" },
        ],
      };

    default: {
      const never: never = event;
      return reject(state, `未知事件 ${JSON.stringify(never)}`);
    }
  }
}

// ─────────────────────────── 辅助 ───────────────────────────

/** 进入某相位的标准副作用:切工具集 + 切角色模型 */
function enter(phase: Phase): Effect[] {
  const effects: Effect[] = [{ type: "SET_TOOLS", phase }];
  const role = ROLE_OF[phase];
  if (role) effects.push({ type: "SET_ROLE", role });
  return effects;
}

function log(line: string): Effect {
  return { type: "LOG", line };
}

function reject(state: MissionState, error: string): TransitionResult {
  return { state, effects: [], error };
}

function setTask(
  tasks: Record<string, TaskState>,
  id: string,
  fn: (t: TaskState) => TaskState,
): Record<string, TaskState> {
  const current: TaskState = tasks[id] ?? {
    id,
    status: "pending",
    attempts: 0,
    sameSignatureCount: 0,
  };
  return { ...tasks, [id]: fn(current) };
}

function nextTask(order: string[], current: string): string | null {
  const i = order.indexOf(current);
  return i >= 0 && i + 1 < order.length ? order[i + 1] : null;
}

function compact(s: string): string {
  return s.replace(/\s+/g, " ").trim().slice(0, 120);
}

/** 便于 hooks 层与测试构造初始状态 */
export function initialState(params: {
  missionId: string;
  tier: Tier;
  taskOrder: string[];
  envFingerprint?: string | null;
}): MissionState {
  const tasks: Record<string, TaskState> = {};
  for (const id of params.taskOrder) {
    tasks[id] = { id, status: "pending", attempts: 0, sameSignatureCount: 0 };
  }
  return {
    missionId: params.missionId,
    tier: params.tier,
    phase: "plan",
    currentTask: null,
    taskOrder: params.taskOrder,
    tasks,
    escalation: { level: 1, history: [] },
    envFingerprint: params.envFingerprint ?? null,
  };
}
