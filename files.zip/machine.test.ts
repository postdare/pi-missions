import { test } from "node:test";
import assert from "node:assert/strict";
import { transition, initialState } from "../machine.ts";
import type { Effect, MissionState, Verdict } from "../types.ts";

const AT = 1756600000000;

const mk = (tier: "quick" | "standard" | "complex" = "standard") =>
  initialState({ missionId: "m1", tier, taskOrder: ["T1", "T2"] });

const pass: Verdict = { outcome: "pass", failing: [], reason: "ok" };
const failed: Verdict = { outcome: "fail", signature: "sig1", failing: [], reason: "AC1 fail" };
const unknown: Verdict = { outcome: "inconclusive", failing: [], reason: "env drift" };

const has = (effects: Effect[], type: Effect["type"]) => effects.some((e) => e.type === type);

/** 把 mission 推到 do 相位 */
function toDo(tier: "quick" | "standard" | "complex" = "standard"): MissionState {
  return transition(mk(tier), { type: "PLAN_FROZEN", at: AT }).state;
}

test("PLAN_FROZEN 冻结 AC 并进入首个任务", () => {
  const r = transition(mk(), { type: "PLAN_FROZEN", at: AT });
  assert.equal(r.state.phase, "do");
  assert.equal(r.state.currentTask, "T1");
  assert.equal(r.state.tasks.T1.attempts, 1);
  assert.ok(has(r.effects, "FREEZE_AC"));
  assert.ok(has(r.effects, "SET_TOOLS"));
  assert.ok(has(r.effects, "SET_ROLE"));
});

test("非法迁移被拒绝且状态不变", () => {
  const s = mk();
  const r = transition(s, { type: "SUBMIT", at: AT });
  assert.ok(r.error);
  assert.equal(r.state, s);
  assert.equal(r.effects.length, 0);
});

test("VERDICT fail 进入 ACT 而非直接重试", () => {
  const s = transition(toDo(), { type: "SUBMIT", at: AT }).state;
  const r = transition(s, { type: "VERDICT", at: AT, verdict: failed });
  assert.equal(r.state.phase, "act");
  assert.equal(r.state.tasks.T1.attempts, 1, "ACT 阶段不应递增 attempts");
});

test("inconclusive 回 DO 且不计入 attempts", () => {
  const s = transition(toDo(), { type: "SUBMIT", at: AT }).state;
  const r = transition(s, { type: "VERDICT", at: AT, verdict: unknown });
  assert.equal(r.state.phase, "do");
  assert.equal(r.state.tasks.T1.attempts, 1);
  assert.ok(has(r.effects, "NOTIFY"));
});

test("ADJUST_DONE 回 DO 并递增 attempts", () => {
  let s = transition(toDo(), { type: "SUBMIT", at: AT }).state;
  s = transition(s, { type: "VERDICT", at: AT, verdict: failed }).state;
  const r = transition(s, { type: "ADJUST_DONE", at: AT });
  assert.equal(r.state.phase, "do");
  assert.equal(r.state.tasks.T1.attempts, 2);
});

test("PASS 推进到下一任务并重置 attempts", () => {
  const s = transition(toDo(), { type: "SUBMIT", at: AT }).state;
  const r = transition(s, { type: "VERDICT", at: AT, verdict: pass });
  assert.equal(r.state.phase, "do");
  assert.equal(r.state.currentTask, "T2");
  assert.equal(r.state.tasks.T1.status, "done");
  assert.equal(r.state.tasks.T2.attempts, 1);
});

test("standard 档任务切换不换脑,complex 档换脑", () => {
  const std = transition(transition(toDo("standard"), { type: "SUBMIT", at: AT }).state, {
    type: "VERDICT", at: AT, verdict: pass,
  });
  assert.equal(has(std.effects, "HANDOFF"), false);

  const cpx = transition(transition(toDo("complex"), { type: "SUBMIT", at: AT }).state, {
    type: "VERDICT", at: AT, verdict: pass,
  });
  assert.ok(has(cpx.effects, "HANDOFF"));
});

test("最后一个任务通过则整体 done", () => {
  let s = toDo();
  s = transition(s, { type: "SUBMIT", at: AT }).state;
  s = transition(s, { type: "VERDICT", at: AT, verdict: pass }).state; // → T2
  s = transition(s, { type: "SUBMIT", at: AT }).state;
  const r = transition(s, { type: "VERDICT", at: AT, verdict: pass });
  assert.equal(r.state.phase, "done");
  assert.equal(r.state.currentTask, null);
});

test("L2 升级必定换脑并重置签名计数", () => {
  let s = transition(toDo(), { type: "SUBMIT", at: AT }).state;
  s = transition(s, { type: "VERDICT", at: AT, verdict: failed }).state;
  s.tasks.T1 = { ...s.tasks.T1, lastSignature: "sig1", sameSignatureCount: 3 };

  const r = transition(s, { type: "ESCALATE", at: AT, to: 2, reason: "同一签名 3 次" });
  assert.equal(r.state.phase, "plan");
  assert.equal(r.state.escalation.level, 2);
  assert.ok(has(r.effects, "HANDOFF"), "I5:升级必须换脑");
  assert.equal(r.state.tasks.T1.sameSignatureCount, 0);
  assert.equal(r.state.escalation.history.length, 1);
});

test("L3 升级先要人工确认,状态不立即迁移", () => {
  let s = transition(toDo(), { type: "SUBMIT", at: AT }).state;
  s = transition(s, { type: "VERDICT", at: AT, verdict: failed }).state;
  s = { ...s, escalation: { level: 2, history: [] } };

  const r = transition(s, { type: "ESCALATE", at: AT, to: 3, reason: "方案也不行" });
  assert.equal(r.state.phase, "act", "确认前不应迁出 act");
  assert.ok(has(r.effects, "CONFIRM"));
  assert.equal(has(r.effects, "HANDOFF"), false);

  const ok = transition(r.state, { type: "ESCALATION_CONFIRMED", at: AT });
  assert.equal(ok.state.phase, "plan");
  assert.ok(has(ok.effects, "ARCHIVE_PLAN"));
  assert.ok(has(ok.effects, "HANDOFF"));
});

test("L3 被拒绝则停机", () => {
  let s = transition(toDo(), { type: "SUBMIT", at: AT }).state;
  s = transition(s, { type: "VERDICT", at: AT, verdict: failed }).state;
  const r = transition(s, { type: "ESCALATION_REJECTED", at: AT });
  assert.equal(r.state.phase, "halted");
});

test("不允许降级", () => {
  let s = transition(toDo(), { type: "SUBMIT", at: AT }).state;
  s = transition(s, { type: "VERDICT", at: AT, verdict: failed }).state;
  s = { ...s, escalation: { level: 3, history: [] } };
  const r = transition(s, { type: "ESCALATE", at: AT, to: 2, reason: "x" });
  assert.ok(r.error);
});

test("reducer 不修改入参", () => {
  const s = mk();
  const snapshot = JSON.stringify(s);
  transition(s, { type: "PLAN_FROZEN", at: AT });
  assert.equal(JSON.stringify(s), snapshot);
});
